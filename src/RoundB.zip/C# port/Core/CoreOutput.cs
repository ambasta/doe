﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net.Sockets;
using System.Runtime.Serialization.Formatters.Binary;
using System.IO;

namespace Doe.Core
{
    public class CoreOutput
    {
        List<string> queue;
        NetworkStream clientStream;

        public CoreOutput(List<string> q, NetworkStream cs)
        {
            queue = q;
            clientStream = cs;
        }

        public void show()
        {
            MemoryStream ms = new MemoryStream();
            BinaryFormatter bf = new BinaryFormatter();
            ASCIIEncoding encoder = new ASCIIEncoding();
            byte[] reply = new byte[4096];

            while (true)
            {
                if (queue.Count == 0)
                {
                    bf.Serialize(ms, (object)"Done");
                    reply = ms.ToArray();

                    clientStream.Write(reply, 0, reply.Length);
                    break;
                }
                else if (queue.Count == 1)
                {
                    continue;
                }
                else
                {
                    string ans = queue[1];

                    bf.Serialize(ms, (object)ans);
                    reply = ms.ToArray();

                    clientStream.Write(reply, 0, reply.Length);
                    queue.Remove(ans);
                    while (true)
                    {
                        reply = new byte[4096];
                        int rb = clientStream.Read(reply, 0, 4096);

                        if (encoder.GetString(reply, 0, rb).Equals("Accepted"))
                        {
                            break;
                        }
                    }
                }
            }
            clientStream.Close();
        }
    }
}
